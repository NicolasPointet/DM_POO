POINTET Nicolas

DM part-1

Etape 5 :

- Web
  Outils pour des applications web

- JPA
  Data en SQL, utilise Hibernate

- H2
  Java SQL database open source et basée sur l'API JDBC

- Devtools
  Outils pour le developpement avec Spring Boot

- Thymeleaf
  Server-side Java template

Etape 13

- Nous avons paramétré lurl dappel /greeting avec @GetMapping("/greeting")

- Nous avons choisi l'HTML à afficher avec le return "greeting"

- Le nom auquel on dit bonjour est choisi avec le paramètre @RequestParam(name="name"), l'attribut name="nameGET" tel qu'indiqué dans le sujet ne fonctionne pas

Etape 17

La valeur par défaut du champ JDBC URL a changée

Etape 18



Etape 20

Oui le contenu du fichier data.sql s'affiche

Etape 23

Le tag Autowired permet à Spring d'assigner une valeur à une propriété.

Etape 30

Bootstrap s'utilise en ajoutant la dépendance Maven assosié pom.xml


DM part 2

Etape 6

1) Oui
2) https://api.darksky.net/forecast/clé_api/long,lat
3) La méthode HTTP GET
4) Avec ?NOM_PARAM=VALEUR
5) Ces information se trouvent dans la section "currently", aux attributs 'summary' et 'temperature'

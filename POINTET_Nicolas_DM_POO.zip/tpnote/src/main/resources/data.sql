INSERT INTO address (id, creation, content, auteur) VALUES (1, CURRENT_TIMESTAMP(), '57 boulevard demorieux', 'Jean VIOLIN');
INSERT INTO address (id, creation, content, auteur) VALUES (2, CURRENT_TIMESTAMP(), '51 allee du gamay, 34080 montpellier', 'Jiro KOI');
